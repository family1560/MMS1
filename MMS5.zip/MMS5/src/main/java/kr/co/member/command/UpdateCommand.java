package kr.co.member.command;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.member.dao.MemberDAO;
import kr.co.member.domain.CommandAction;
import kr.co.member.domain.MemberDTO;

public class UpdateCommand implements Command {

	@Override
	public CommandAction execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String sId = request.getParameter("id");
		int id = Integer.parseInt(sId);
		
		String name = request.getParameter("name");
		
		String sAge = request.getParameter("age");
		int age = Integer.parseInt(sAge);
		
		MemberDAO dao = new MemberDAO();
		MemberDTO findDto = dao.findDtoById(new MemberDTO(id, null, 0));
		
		MemberDTO dto = new MemberDTO();
		
		if(findDto != null) {
			dto.setId(findDto.getId());
			
			if(!name.equals("")) {
				dto.setName(name);
			}
			
			if(age != -1) {
				dto.setAge(age);
			}
			
			dao.update(dto);
			
		}else {
			request.getRequestDispatcher("member/jsp/nofindid.jsp").forward(request, response);
		}

		return new CommandAction("list.do", true);
	}

}
