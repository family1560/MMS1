package kr.co.member.command;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.member.dao.MemberDAO;
import kr.co.member.domain.CommandAction;
import kr.co.member.domain.MemberDTO;

public class DeleteCommand implements Command {

	@Override
	public CommandAction execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String sId = request.getParameter("id");
		int id = Integer.parseInt(sId);
		
		MemberDAO dao = new MemberDAO();
		MemberDTO findDto = dao.findDtoById(new MemberDTO(id, null, 0));
		
		if(findDto != null) {
			dao.delete(findDto);
	
		}else {
			request.getRequestDispatcher("member/jsp/nofindid.jsp").forward(request, response);
		}
		
		return new CommandAction("list.do", true);
	}

}
